@extends('front-end.fe-layout')

@section('content')

    <!-- Top News Start-->
    <div class="top-news">
        <div class="container">
            <div class="row">
                @if(isset($today_book))
                <div class="col-md-12">
                    <div class="row tn-slider">
                        <div class="col-md-12">
                            <div class="tn-img copy-code">
                                @if($today_book['file_type']== 'jpg' or $today_book['file_type']== 'jpeg' or $today_book['file_type']== 'png')
                                <img src="{{url('')}}/uploads/tdbooks/{{ $today_book->file_name }}" alt="{{ $today_book->caption }}" />
                                @else
                                <video width="100%" controls autoplay loop>
                                    <source src="{{url('')}}/uploads/tdbooks/{{ $today_book->file_name }}#t=0.3" type="video/{{ $today_book['file_type'] }}">
                                Your browser does not support HTML video.
                                </video>
                                @endif
                                <div class="tn-title">
                                    <a href="/copy-code">{{ $today_book->caption }}</a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                @endif

                <!-- Article List -->
                @if(! $articles->isEmpty())
                <div class="col-md-12" style="padding:30px 10px;">
                    <hr/>
                    <h4>Follow us on Instagram: @Exola.TV</h4>
                    <div class="row">
                        <?php $count = 0; ?>
                        @forelse($articles as $article)
                            <div class="col-md-3" style="padding:10px">
                                <div class="tn-img art-link" data-id="{{ $article->id }}">
                                    <img src="{{url('')}}/uploads/articles_post/{{ $article->image_name }}" alt="{{ $article->title }}" style="width:100%;height:225px;">
                                    <div class="tn-title">
                                        <a href="/article/{{ $article->id }}">{{ $article->title }}</a>
                                    </div>
                                </div>
                                <p class="float-right" style="font-size:12px;margin:10px;">Posted: {{ \Carbon\Carbon::parse($article->created_at)->format('j F, Y') }}</p>
                            </div>
                        @empty
                        @endforelse
                    </div>
                    <a href="" type="button" class="btn btn-primary float-right btn-sm">All News</a>
                    <br/>
                    <hr/>
                </div>
                @endif


            </div>
        </div>
    </div>
    <!-- Top News End-->

    <!-- Category News Start-->
    <div class="cat-news">
        <div class="container">
            <div class="row" style="padding:10px;">
                @if(! $sprs_t->isEmpty() and $sprs_t->count() > 3)
                <div class="col-md-6">
                <h6>Savage Post & Response - Twitter</h6>
                    <div class="row cn-slider">
                        @forelse($sprs_t as $spr)
                            <div class="col-md-3">
                                <div class="cn-img">
                                    @if($spr['file_type']== 'jpg' or $spr['file_type']== 'jpeg' or $spr['file_type']== 'png')
                                    <img src="{{url('')}}/uploads/spr_posts/{{ $spr->file_name }}"/>
                                    <div class="cn-title">
                                        <a href="">{{ $spr->caption }}</a>
                                    </div>
                                    @else
                                    <video width="100%" controls>
                                        <source src="{{url('')}}/uploads/spr_posts/{{ $spr->file_name }}#t=0.1" type="video/{{ $spr['file_type'] }}" style="height:225px;">
                                    Your browser does not support HTML video.
                                    </video>
                                    <div class="">
                                    <i class="fa fa-film float-right" style="color:#e60000;font-size:24px;" aria-hidden="true"></i>
                                        <a href="" style="color:black;">{{ $spr->caption }}</a>
                                    </div>
                                    @endif
                                </div>
                                <p class="float-right" style="font-size:12px;margin:10px;">Posted: {{ \Carbon\Carbon::parse($spr->created_at)->format('j F, Y') }}</p>
                            </div>
                        @empty
                        @endforelse
                    </div>
                    <hr/>
                </div>
                @endif
                

                @if(! $sprs_i->isEmpty() and $sprs_i->count() > 3)
                <div class="col-md-6">
                <h6>Savage Post & Response - Instagram</h6>
                    <div class="row cn-slider">
                        @forelse($sprs_i as $spr)
                            <div class="col-md-3">
                                <div class="cn-img">
                                    @if($spr['file_type']== 'jpg' or $spr['file_type']== 'jpeg' or $spr['file_type']== 'png')
                                    <img src="{{url('')}}/uploads/spr_posts/{{ $spr->file_name }}"/>
                                    <div class="cn-title">
                                        <a href="">{{ $spr->caption }}</a>
                                    </div>
                                    @else
                                    <video width="100%" controls>
                                        <source src="{{url('')}}/uploads/spr_posts/{{ $spr->file_name }}#t=0.1" type="video/{{ $spr['file_type'] }}">
                                    Your browser does not support HTML video.
                                    </video>
                                    @endif
                                    
                                </div>
                                <p class="float-right" style="font-size:12px;margin:10px;">Posted: {{ \Carbon\Carbon::parse($spr->created_at)->format('j F, Y') }}</p>
                                <!-- <div class="row" style="padding:5px;text-align:center;">
                                    <div class="col">
                                        <a type="button" style="color:grey;"><i class="fa fa-comments"></i> <span style="font-size:14px">0</span></a>
                                    </div>
                                    <div class="col">
                                    <a type="button" data-id="{{ $spr->id }}" data-count="0" data-active="0" style="color:grey;" class="like"><i class="fa fa-thumbs-up"></i> <span style="font-size:14px" class="countdisp">0</span></a>
                                    </div>
                                    <div class="col">
                                        <a type="button" data-id="{{ $spr->id }}" data-count="0" data-active="0" style="color:grey;" class="dislike"><i class="fa fa-thumbs-down"></i> <span style="font-size:14px" class="countdisp">0</span></a>
                                    </div>
                                </div> -->
                            </div>
                        @empty
                        @endforelse
                    </div>
                    <hr/>
                </div>
                @endif

                @if(! $sprs_f->isEmpty() and $sprs_f->count() > 3)
                    <div class="col-md-6">
                    <h6>Savage Post & Response - Facebook</h6>
                        <div class="row cn-slider">
                            @forelse($sprs_f as $spr)
                                <div class="col-md-3">
                                    <div class="cn-img">
                                        @if($spr['file_type']== 'jpg' or $spr['file_type']== 'jpeg' or $spr['file_type']== 'png')
                                        <img src="{{url('')}}/uploads/spr_posts/{{ $spr->file_name }}"/>
                                        <div class="cn-title">
                                            <a href="">{{ $spr->caption }}</a>
                                        </div>
                                        @else
                                        <video width="100%" controls>
                                            <source src="{{url('')}}/uploads/spr_posts/{{ $spr->file_name }}#t=0.1" type="video/{{ $spr['file_type'] }}">
                                        Your browser does not support HTML video.
                                        </video>
                                        <div class="">
                                        <i class="fa fa-film float-right" style="color:#e60000;font-size:24px;" aria-hidden="true"></i>
                                            <a href="" style="color:black;">{{ $spr->caption }}</a>
                                        </div>
                                        @endif
                                    </div>
                                    <p class="float-right" style="font-size:12px;margin:10px;">Posted: {{ \Carbon\Carbon::parse($spr->created_at)->format('j F, Y') }}</p>
                                </div>
                            @empty
                            @endforelse
                        </div>
                        <hr/> 
                    </div>
                    @endif

                    <?php $sn = 0; ?>
                    @if(! $betcodes->isEmpty() and $betcodes->count() > 2)
                    <div class="col-md-6">
                    <h6>Bet9ja Booking Codes</h6>
                        <div class="row cn-slider">
                            @forelse($betcodes as $code)
                            <?php $sn = $sn+1; ?>
                            <div class="col-md-3">
                                <div class="bet-div">
                                    <p class="float-right bet-font"><b>{{ $code->bet_code }} | {{ $code->odds }}</b></p>
                                    <p><b>{{ $sn }}</b></p>
                                    <hr/>
                                    @foreach($betselections->where('bet_id', $code->id) as $select)
                                        <div>
                                            <p class="float-right bet-font">{{ $select->selection }}<p>
                                            <p class="bet-font">{{ $select->home }}  <b>-</b>  {{ $select->away }}</p>
                                        </div>
                                    @endforeach
                                </div>
                                <p class="float-right" style="font-size:12px;margin:10px;">Posted: {{ \Carbon\Carbon::parse($code->created_at)->format('j F, Y') }}</p>
                            </div>
                            @empty
                            @endforelse
                        </div>
                        <hr/>
                    </div>
                    @endif

            </div>
        </div>
    </div>
    <!-- Category News End-->

<script>

    
    
    $(".art-link").on("click", function(){
        var dataId = $(this).attr("data-id");
        window.location.replace("/article/"+dataId);
    });
    
    $(".copy-code").on("click", function(){
        // var dataId = $(this).attr("data-id");
        window.location.replace("/copy-code/");
    });
    
    $(".dislike").on("click", function(){
        // var inc_nums = [5,7,10];
        var dataId = $(this).attr("data-id");
        var dataActive = parseInt($(this).attr("data-active"));
        var dataCount = parseInt($(this).attr("data-count"));
        if(dataActive === 0){
            dataCount=dataCount + 1;
            $(this).attr("data-count", dataCount);
            $(this).attr("data-active", 1);
            $(this).css("color", "red");
            $(this).find(".countdisp").replaceWith('<span style="font-size:14px" class="countdisp">'+dataCount+'</span>');
        }else{
            dataCount=dataCount - 1;
            $(this).attr("data-count", dataCount);
            $(this).attr("data-active", 0);
            $(this).css("color", "grey");
            $(this).find(".countdisp").replaceWith('<span style="font-size:14px" class="countdisp">'+dataCount+'</span>');
        }
    });
    
    $(".like").on("click", function(){
        var inc_nums = [5,7,10];
        var dataId = $(this).attr("data-id");
        var dataActive = parseInt($(this).attr("data-active"));
        var dataCount = parseInt($(this).attr("data-count"));
        if(dataActive === 0){
            dataCount=dataCount + inc_nums[Math.floor(Math.random() * inc_nums.length)];
            $(this).attr("data-count", dataCount);
            $(this).attr("data-active", 1);
            $(this).css("color", "#1d31ad");
            $(this).find(".countdisp").replaceWith('<span style="font-size:14px" class="countdisp">'+dataCount+'</span>');
        }else{
            dataCount=dataCount - 1;
            $(this).attr("data-count", dataCount);
            $(this).attr("data-active", 0);
            $(this).css("color", "grey");
            $(this).find(".countdisp").replaceWith('<span style="font-size:14px" class="countdisp">'+dataCount+'</span>');
        }
    });
</script>
@endsection('content')